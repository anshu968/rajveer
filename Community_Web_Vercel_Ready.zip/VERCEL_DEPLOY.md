# Vercel deployment

This project has been prepared with a Vercel Python entrypoint.

## Deploy
1. Upload/import this project into Vercel.
2. Vercel should detect `vercel.json` and `api/index.py`.
3. If the app uses secrets, add the required environment variables in Vercel Project Settings.
4. Deploy.

## Important
The Flask app itself is kept in `run.py`; `api/index.py` exposes its `app` object to Vercel.

If the application stores uploads or a local SQLite/database file, those files should be moved to persistent external storage/database for production because Vercel's serverless filesystem is not persistent.

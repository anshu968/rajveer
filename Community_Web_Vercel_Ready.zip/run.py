from flask import Flask, render_template, request, redirect, url_for, session, flash
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
import sqlite3
import os
import random
import string
from datetime import datetime

app = Flask(__name__)
app.secret_key = 'nexus-community-secret-key-2026-xyz'
app.config['UPLOAD_FOLDER'] = 'static/uploads'
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024

ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif', 'webp', 'svg', 'pdf', 'txt', 'doc', 'docx', 'zip', 'rar', 'mp4', 'webm'}

def get_db():
    conn = sqlite3.connect('database.db')
    conn.row_factory = sqlite3.Row
    return conn

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def gen_order_number():
    return 'ORD-' + ''.join(random.choices(string.ascii_uppercase + string.digits, k=8))

def get_setting(key, default=''):
    conn = get_db()
    row = conn.execute('SELECT value FROM settings WHERE key = ?', (key,)).fetchone()
    conn.close()
    return row['value'] if row else default

def set_setting(key, value):
    conn = get_db()
    existing = conn.execute('SELECT key FROM settings WHERE key = ?', (key,)).fetchone()
    if existing:
        conn.execute('UPDATE settings SET value = ? WHERE key = ?', (value, key))
    else:
        conn.execute('INSERT INTO settings (key, value) VALUES (?, ?)', (key, value))
    conn.commit()
    conn.close()

def init_db():
    conn = get_db()
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        created_at TEXT,
        is_banned INTEGER DEFAULT 0
    )''')
    c.execute('''CREATE TABLE IF NOT EXISTS admin (
        id INTEGER PRIMARY KEY,
        username TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL
    )''')
    c.execute('''CREATE TABLE IF NOT EXISTS plans (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        description TEXT,
        price TEXT,
        emoji TEXT,
        image TEXT,
        reward TEXT,
        created_at TEXT
    )''')
    c.execute('''CREATE TABLE IF NOT EXISTS about (
        id INTEGER PRIMARY KEY,
        content TEXT
    )''')
    c.execute('''CREATE TABLE IF NOT EXISTS settings (
        key TEXT PRIMARY KEY,
        value TEXT
    )''')
    c.execute('''CREATE TABLE IF NOT EXISTS orders (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        order_number TEXT UNIQUE NOT NULL,
        user_id INTEGER NOT NULL,
        plan_id INTEGER NOT NULL,
        status TEXT DEFAULT 'pending',
        proof_image TEXT,
        proof_note TEXT,
        admin_note TEXT,
        reward_text TEXT,
        reward_file TEXT,
        reward_file_name TEXT,
        created_at TEXT,
        updated_at TEXT,
        FOREIGN KEY (user_id) REFERENCES users(id),
        FOREIGN KEY (plan_id) REFERENCES plans(id)
    )''')
    c.execute('''CREATE TABLE IF NOT EXISTS reviews (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        display_name TEXT NOT NULL,
        content TEXT NOT NULL,
        reward_text TEXT,
        rating INTEGER DEFAULT 5,
        created_at TEXT,
        FOREIGN KEY (user_id) REFERENCES users(id)
    )''')
    c.execute('''CREATE TABLE IF NOT EXISTS announcements (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        content TEXT NOT NULL,
        created_at TEXT
    )''')
    c.execute('''CREATE TABLE IF NOT EXISTS chat_messages (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        sender_type TEXT NOT NULL,
        message TEXT,
        file_path TEXT,
        file_name TEXT,
        created_at TEXT,
        is_read INTEGER DEFAULT 0,
        FOREIGN KEY (user_id) REFERENCES users(id)
    )''')

    # Migrations for existing DBs
    try:
        c.execute('ALTER TABLE orders ADD COLUMN reward_text TEXT')
    except: pass
    try:
        c.execute('ALTER TABLE orders ADD COLUMN reward_file TEXT')
    except: pass
    try:
        c.execute('ALTER TABLE orders ADD COLUMN reward_file_name TEXT')
    except: pass
    try:
        c.execute('ALTER TABLE reviews ADD COLUMN user_id INTEGER')
    except: pass

    admin = c.execute('SELECT * FROM admin WHERE id = 1').fetchone()
    if not admin:
        c.execute('INSERT INTO admin (id, username, password) VALUES (1, ?, ?)',
                  ('admin', generate_password_hash('admin123')))
    about = c.execute('SELECT * FROM about WHERE id = 1').fetchone()
    if not about:
        default_about = '''We are a trusted platform with over 500+ satisfied members worldwide.
No scams. No hidden fees. Just pure value and reliability.
Our community grows every day because we deliver what we promise.
Join thousands who already trust us for quality service and support.'''
        c.execute('INSERT INTO about (id, content) VALUES (1, ?)', (default_about,))
    defaults = {
        'website_name': 'Community Web',
        'discord_link': 'https://discord.gg/pF2NHhEtz',
        'youtube_link': 'https://youtube.com',
        'payment_image': '',
        'custom_bg_url': 'https://motionbgs.com/media/9938/herobrine.960x540.mp4',
        'payment_instructions': 'Scan the UPI QR / payment method below and complete payment. Then upload your payment proof.'
    }
    for k, v in defaults.items():
        exists = c.execute('SELECT key FROM settings WHERE key = ?', (k,)).fetchone()
        if not exists:
            c.execute('INSERT INTO settings (key, value) VALUES (?, ?)', (k, v))
    conn.commit()
    conn.close()

def site_name():
    return get_setting('website_name', 'Community Web')

def is_video_url(url):
    if not url:
        return False
    lower = url.lower().split('?')[0]
    return lower.endswith(('.mp4', '.webm', '.ogg', '.mov'))

# ==================== AUTH ====================

@app.route('/')
def index():
    if 'user_id' in session:
        return redirect(url_for('website'))
    if 'admin_id' in session:
        return redirect(url_for('admin_panel'))
    return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '')
        conn = get_db()
        admin = conn.execute('SELECT * FROM admin WHERE username = ?', (username,)).fetchone()
        if admin and check_password_hash(admin['password'], password):
            session.clear()
            session['admin_id'] = admin['id']
            session['admin_username'] = admin['username']
            conn.close()
            return redirect(url_for('admin_panel'))
        user = conn.execute('SELECT * FROM users WHERE username = ?', (username,)).fetchone()
        conn.close()
        if user and check_password_hash(user['password'], password):
            if user['is_banned']:
                flash('Your account has been suspended.', 'error')
                return render_template('login.html', site_name=site_name(),
                                       custom_bg=get_setting('custom_bg_url'),
                                       is_video=is_video_url(get_setting('custom_bg_url')))
            session.clear()
            session['user_id'] = user['id']
            session['username'] = user['username']
            return redirect(url_for('website'))
        flash('Invalid username or password', 'error')
    bg = get_setting('custom_bg_url')
    return render_template('login.html', site_name=site_name(), custom_bg=bg, is_video=is_video_url(bg))

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '')
        confirm = request.form.get('confirm', '')
        if not username or not password:
            flash('All fields are required', 'error')
        elif len(username) < 3:
            flash('Username must be at least 3 characters', 'error')
        elif len(password) < 4:
            flash('Password must be at least 4 characters', 'error')
        elif password != confirm:
            flash('Passwords do not match', 'error')
        else:
            conn = get_db()
            try:
                conn.execute('INSERT INTO users (username, password, created_at) VALUES (?, ?, ?)',
                             (username, generate_password_hash(password), datetime.now().isoformat()))
                conn.commit()
                flash('Registration successful! Please login.', 'success')
                conn.close()
                return redirect(url_for('login'))
            except sqlite3.IntegrityError:
                flash('Username already exists', 'error')
            conn.close()
    bg = get_setting('custom_bg_url')
    return render_template('register.html', site_name=site_name(), custom_bg=bg, is_video=is_video_url(bg))

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))

# ==================== USER ====================

@app.route('/website')
def website():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    conn = get_db()
    plans = conn.execute('SELECT * FROM plans ORDER BY id DESC').fetchall()
    about = conn.execute('SELECT content FROM about WHERE id = 1').fetchone()
    reviews = conn.execute('SELECT * FROM reviews ORDER BY id DESC LIMIT 30').fetchall()
    announcements = conn.execute('SELECT * FROM announcements ORDER BY id DESC LIMIT 10').fetchall()
    orders = conn.execute('''SELECT o.*, p.title as plan_title, p.reward as plan_reward, p.image as plan_image, p.emoji as plan_emoji
                             FROM orders o JOIN plans p ON o.plan_id = p.id
                             WHERE o.user_id = ? ORDER BY o.id DESC''', (session['user_id'],)).fetchall()
    # Accepted plan IDs for this user (to show rewards on plan cards)
    accepted_plan_ids = set()
    accepted_rewards = {}
    for o in orders:
        if o['status'] == 'accepted':
            accepted_plan_ids.add(o['plan_id'])
            accepted_rewards[o['plan_id']] = {
                'reward_text': o['reward_text'] or o['plan_reward'],
                'reward_file': o['reward_file'],
                'reward_file_name': o['reward_file_name'],
                'order_id': o['id'],
                'order_number': o['order_number']
            }
    pending_orders = [o for o in orders if o['status'] in ('pending', 'proof_submitted')]
    unread = conn.execute('SELECT COUNT(*) as c FROM chat_messages WHERE user_id = ? AND sender_type = ? AND is_read = 0',
                          (session['user_id'], 'admin')).fetchone()['c']
    conn.close()
    bg = get_setting('custom_bg_url')
    return render_template('website.html',
                           username=session.get('username'),
                           site_name=site_name(),
                           plans=plans,
                           about_content=about['content'] if about else '',
                           reviews=reviews,
                           announcements=announcements,
                           orders=orders,
                           pending_orders=pending_orders,
                           accepted_plan_ids=accepted_plan_ids,
                           accepted_rewards=accepted_rewards,
                           unread_chat=unread,
                           discord_link=get_setting('discord_link'),
                           youtube_link=get_setting('youtube_link'),
                           custom_bg=bg,
                           is_video=is_video_url(bg))

@app.route('/order/<int:plan_id>')
def create_order(plan_id):
    if 'user_id' not in session:
        return redirect(url_for('login'))
    conn = get_db()
    plan = conn.execute('SELECT * FROM plans WHERE id = ?', (plan_id,)).fetchone()
    if not plan:
        conn.close()
        flash('Plan not found', 'error')
        return redirect(url_for('website'))
    existing = conn.execute('SELECT * FROM orders WHERE user_id = ? AND plan_id = ? AND status IN ("pending", "proof_submitted")',
                            (session['user_id'], plan_id)).fetchone()
    if existing:
        conn.close()
        return redirect(url_for('billing', order_id=existing['id']))
    # Also block if already accepted
    accepted = conn.execute('SELECT * FROM orders WHERE user_id = ? AND plan_id = ? AND status = "accepted"',
                            (session['user_id'], plan_id)).fetchone()
    if accepted:
        conn.close()
        flash('You already own this plan!', 'success')
        return redirect(url_for('website'))
    order_num = gen_order_number()
    now = datetime.now().isoformat()
    c = conn.execute('''INSERT INTO orders (order_number, user_id, plan_id, status, created_at, updated_at)
                        VALUES (?, ?, ?, 'pending', ?, ?)''',
                     (order_num, session['user_id'], plan_id, now, now))
    order_id = c.lastrowid
    conn.commit()
    conn.close()
    return redirect(url_for('billing', order_id=order_id))

@app.route('/billing/<int:order_id>', methods=['GET', 'POST'])
def billing(order_id):
    if 'user_id' not in session:
        return redirect(url_for('login'))
    conn = get_db()
    order = conn.execute('''SELECT o.*, p.title as plan_title, p.price as plan_price, p.description as plan_desc,
                                   p.image as plan_image, p.emoji as plan_emoji, p.reward as plan_reward
                            FROM orders o JOIN plans p ON o.plan_id = p.id
                            WHERE o.id = ? AND o.user_id = ?''', (order_id, session['user_id'])).fetchone()
    if not order:
        conn.close()
        flash('Order not found', 'error')
        return redirect(url_for('website'))
    if request.method == 'POST' and order['status'] in ('pending', 'proof_submitted'):
        note = request.form.get('proof_note', '').strip()
        proof_path = order['proof_image']
        if 'proof' in request.files:
            f = request.files['proof']
            if f and f.filename and allowed_file(f.filename):
                fname = secure_filename(f.filename)
                fname = f"proof_{order_id}_{datetime.now().strftime('%Y%m%d%H%M%S')}_{fname}"
                f.save(os.path.join(app.config['UPLOAD_FOLDER'], fname))
                proof_path = f"uploads/{fname}"
        if proof_path or note:
            conn.execute('''UPDATE orders SET proof_image = ?, proof_note = ?, status = 'proof_submitted', updated_at = ?
                            WHERE id = ?''', (proof_path, note, datetime.now().isoformat(), order_id))
            conn.commit()
            flash('Payment proof submitted! Waiting for review.', 'success')
            order = conn.execute('''SELECT o.*, p.title as plan_title, p.price as plan_price, p.description as plan_desc,
                                           p.image as plan_image, p.emoji as plan_emoji, p.reward as plan_reward
                                    FROM orders o JOIN plans p ON o.plan_id = p.id
                                    WHERE o.id = ?''', (order_id,)).fetchone()
    conn.close()
    bg = get_setting('custom_bg_url')
    return render_template('billing.html',
                           order=order,
                           site_name=site_name(),
                           username=session.get('username'),
                           payment_image=get_setting('payment_image'),
                           payment_instructions=get_setting('payment_instructions'),
                           custom_bg=bg,
                           is_video=is_video_url(bg))

@app.route('/rewards')
def rewards():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    conn = get_db()
    completed = conn.execute('''SELECT o.*, p.title as plan_title, p.reward as plan_reward, p.image as plan_image, p.emoji as plan_emoji
                                FROM orders o JOIN plans p ON o.plan_id = p.id
                                WHERE o.user_id = ? AND o.status = 'accepted'
                                ORDER BY o.updated_at DESC''', (session['user_id'],)).fetchall()
    conn.close()
    bg = get_setting('custom_bg_url')
    return render_template('rewards.html',
                           rewards=completed,
                           site_name=site_name(),
                           username=session.get('username'),
                           custom_bg=bg,
                           is_video=is_video_url(bg))

@app.route('/chat', methods=['GET', 'POST'])
def chat():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    uid = session['user_id']
    conn = get_db()
    if request.method == 'POST':
        msg = request.form.get('message', '').strip()
        file_path = None
        file_name = None
        if 'file' in request.files:
            f = request.files['file']
            if f and f.filename and allowed_file(f.filename):
                fname = secure_filename(f.filename)
                fname = f"chat_{uid}_{datetime.now().strftime('%Y%m%d%H%M%S')}_{fname}"
                f.save(os.path.join(app.config['UPLOAD_FOLDER'], fname))
                file_path = f"uploads/{fname}"
                file_name = secure_filename(request.files['file'].filename)
        if msg or file_path:
            conn.execute('''INSERT INTO chat_messages (user_id, sender_type, message, file_path, file_name, created_at)
                            VALUES (?, 'user', ?, ?, ?, ?)''',
                         (uid, msg, file_path, file_name, datetime.now().isoformat()))
            conn.commit()
        return redirect(url_for('chat'))
    conn.execute('UPDATE chat_messages SET is_read = 1 WHERE user_id = ? AND sender_type = ?', (uid, 'admin'))
    conn.commit()
    messages = conn.execute('SELECT * FROM chat_messages WHERE user_id = ? ORDER BY id ASC', (uid,)).fetchall()
    # Pending orders for context
    pending = conn.execute('''SELECT o.order_number, p.title FROM orders o JOIN plans p ON o.plan_id = p.id
                              WHERE o.user_id = ? AND o.status IN ("pending","proof_submitted")''', (uid,)).fetchall()
    conn.close()
    bg = get_setting('custom_bg_url')
    return render_template('chat.html',
                           messages=messages,
                           site_name=site_name(),
                           username=session.get('username'),
                           pending=pending,
                           custom_bg=bg,
                           is_video=is_video_url(bg))

@app.route('/submit_review', methods=['POST'])
def submit_review():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    content = request.form.get('content', '').strip()
    rating = int(request.form.get('rating', 5) or 5)
    rating = max(1, min(5, rating))
    if not content or len(content) < 5:
        flash('Review must be at least 5 characters.', 'error')
        return redirect(url_for('website') + '#reviews')
    conn = get_db()
    conn.execute('''INSERT INTO reviews (user_id, display_name, content, rating, created_at)
                    VALUES (?, ?, ?, ?, ?)''',
                 (session['user_id'], session.get('username'), content, rating, datetime.now().isoformat()))
    conn.commit()
    conn.close()
    flash('Review posted! Thank you.', 'success')
    return redirect(url_for('website') + '#reviews')

# ==================== ADMIN ====================

@app.route('/admin')
def admin_panel():
    if 'admin_id' not in session:
        return redirect(url_for('login'))
    conn = get_db()
    plans = conn.execute('SELECT * FROM plans ORDER BY id DESC').fetchall()
    about = conn.execute('SELECT content FROM about WHERE id = 1').fetchone()
    users = conn.execute('SELECT * FROM users ORDER BY id DESC').fetchall()
    orders = conn.execute('''SELECT o.*, u.username, p.title as plan_title
                             FROM orders o JOIN users u ON o.user_id = u.id JOIN plans p ON o.plan_id = p.id
                             ORDER BY o.id DESC''').fetchall()
    reviews = conn.execute('SELECT * FROM reviews ORDER BY id DESC').fetchall()
    announcements = conn.execute('SELECT * FROM announcements ORDER BY id DESC').fetchall()
    chat_users = conn.execute('''SELECT u.id, u.username,
                                 (SELECT COUNT(*) FROM chat_messages cm WHERE cm.user_id = u.id AND cm.sender_type = 'user' AND cm.is_read = 0) as unread,
                                 (SELECT message FROM chat_messages cm WHERE cm.user_id = u.id ORDER BY cm.id DESC LIMIT 1) as last_msg
                                 FROM users u
                                 WHERE EXISTS (SELECT 1 FROM chat_messages cm WHERE cm.user_id = u.id)
                                 ORDER BY unread DESC, u.username''').fetchall()
    users_count = conn.execute('SELECT COUNT(*) as c FROM users').fetchone()['c']
    pending_orders = conn.execute('SELECT COUNT(*) as c FROM orders WHERE status IN ("pending", "proof_submitted")').fetchone()['c']
    conn.close()
    return render_template('admin.html',
                           admin_username=session.get('admin_username'),
                           site_name=site_name(),
                           plans=plans,
                           about_content=about['content'] if about else '',
                           users=users,
                           orders=orders,
                           reviews=reviews,
                           announcements=announcements,
                           chat_users=chat_users,
                           users_count=users_count,
                           pending_orders=pending_orders,
                           settings={
                               'website_name': get_setting('website_name'),
                               'discord_link': get_setting('discord_link'),
                               'youtube_link': get_setting('youtube_link'),
                               'payment_image': get_setting('payment_image'),
                               'custom_bg_url': get_setting('custom_bg_url'),
                               'payment_instructions': get_setting('payment_instructions'),
                           })

@app.route('/admin/add_plan', methods=['POST'])
def add_plan():
    if 'admin_id' not in session:
        return redirect(url_for('login'))
    title = request.form.get('title', '').strip()
    description = request.form.get('description', '').strip()
    price = request.form.get('price', '').strip()
    emoji = request.form.get('emoji', '').strip()
    reward = request.form.get('reward', '').strip()
    image_path = None
    if 'image' in request.files:
        f = request.files['image']
        if f and f.filename and allowed_file(f.filename):
            fname = f"{datetime.now().strftime('%Y%m%d%H%M%S')}_{secure_filename(f.filename)}"
            f.save(os.path.join(app.config['UPLOAD_FOLDER'], fname))
            image_path = f"uploads/{fname}"
    if title:
        conn = get_db()
        conn.execute('''INSERT INTO plans (title, description, price, emoji, image, reward, created_at)
                        VALUES (?, ?, ?, ?, ?, ?, ?)''',
                     (title, description, price, emoji, image_path, reward, datetime.now().isoformat()))
        conn.commit()
        conn.close()
        flash('Plan added!', 'success')
    return redirect(url_for('admin_panel') + '#plans')

@app.route('/admin/edit_plan/<int:plan_id>', methods=['POST'])
def edit_plan(plan_id):
    if 'admin_id' not in session:
        return redirect(url_for('login'))
    title = request.form.get('title', '').strip()
    description = request.form.get('description', '').strip()
    price = request.form.get('price', '').strip()
    emoji = request.form.get('emoji', '').strip()
    reward = request.form.get('reward', '').strip()
    conn = get_db()
    plan = conn.execute('SELECT * FROM plans WHERE id = ?', (plan_id,)).fetchone()
    image_path = plan['image'] if plan else None
    if 'image' in request.files:
        f = request.files['image']
        if f and f.filename and allowed_file(f.filename):
            fname = f"{datetime.now().strftime('%Y%m%d%H%M%S')}_{secure_filename(f.filename)}"
            f.save(os.path.join(app.config['UPLOAD_FOLDER'], fname))
            image_path = f"uploads/{fname}"
    if title:
        conn.execute('''UPDATE plans SET title=?, description=?, price=?, emoji=?, image=?, reward=? WHERE id=?''',
                     (title, description, price, emoji, image_path, reward, plan_id))
        conn.commit()
        flash('Plan updated!', 'success')
    conn.close()
    return redirect(url_for('admin_panel') + '#plans')

@app.route('/admin/delete_plan/<int:plan_id>', methods=['POST'])
def delete_plan(plan_id):
    if 'admin_id' not in session:
        return redirect(url_for('login'))
    conn = get_db()
    plan = conn.execute('SELECT image FROM plans WHERE id = ?', (plan_id,)).fetchone()
    if plan and plan['image']:
        try: os.remove(os.path.join('static', plan['image']))
        except: pass
    conn.execute('DELETE FROM plans WHERE id = ?', (plan_id,))
    conn.commit()
    conn.close()
    flash('Plan deleted!', 'success')
    return redirect(url_for('admin_panel') + '#plans')

@app.route('/admin/update_about', methods=['POST'])
def update_about():
    if 'admin_id' not in session:
        return redirect(url_for('login'))
    content = request.form.get('content', '').strip()
    conn = get_db()
    conn.execute('UPDATE about SET content = ? WHERE id = 1', (content,))
    conn.commit()
    conn.close()
    flash('About updated!', 'success')
    return redirect(url_for('admin_panel') + '#about')

@app.route('/admin/change_password', methods=['POST'])
def change_password():
    if 'admin_id' not in session:
        return redirect(url_for('login'))
    current = request.form.get('current_password', '')
    new_pass = request.form.get('new_password', '')
    confirm = request.form.get('confirm_password', '')
    conn = get_db()
    admin = conn.execute('SELECT * FROM admin WHERE id = 1').fetchone()
    if not check_password_hash(admin['password'], current):
        flash('Current password incorrect', 'error')
    elif len(new_pass) < 4:
        flash('New password too short', 'error')
    elif new_pass != confirm:
        flash('Passwords do not match', 'error')
    else:
        conn.execute('UPDATE admin SET password = ? WHERE id = 1', (generate_password_hash(new_pass),))
        conn.commit()
        flash('Password changed!', 'success')
    conn.close()
    return redirect(url_for('admin_panel') + '#settings')

@app.route('/admin/settings', methods=['POST'])
def update_settings():
    if 'admin_id' not in session:
        return redirect(url_for('login'))
    set_setting('website_name', request.form.get('website_name', 'Community Web').strip() or 'Community Web')
    set_setting('discord_link', request.form.get('discord_link', '').strip())
    set_setting('youtube_link', request.form.get('youtube_link', '').strip())
    set_setting('custom_bg_url', request.form.get('custom_bg_url', '').strip())
    set_setting('payment_instructions', request.form.get('payment_instructions', '').strip())
    if 'payment_image' in request.files:
        f = request.files['payment_image']
        if f and f.filename and allowed_file(f.filename):
            fname = f"payment_{datetime.now().strftime('%Y%m%d%H%M%S')}_{secure_filename(f.filename)}"
            f.save(os.path.join(app.config['UPLOAD_FOLDER'], fname))
            set_setting('payment_image', f"uploads/{fname}")
    flash('Settings saved!', 'success')
    return redirect(url_for('admin_panel') + '#settings')

@app.route('/admin/order/<int:order_id>/<action>', methods=['POST'])
def manage_order(order_id, action):
    if 'admin_id' not in session:
        return redirect(url_for('login'))
    note = request.form.get('admin_note', '').strip()
    reward_text = request.form.get('reward_text', '').strip()
    conn = get_db()
    reward_file = None
    reward_file_name = None
    if 'reward_file' in request.files:
        f = request.files['reward_file']
        if f and f.filename and allowed_file(f.filename):
            fname = secure_filename(f.filename)
            saved = f"reward_{order_id}_{datetime.now().strftime('%Y%m%d%H%M%S')}_{fname}"
            f.save(os.path.join(app.config['UPLOAD_FOLDER'], saved))
            reward_file = f"uploads/{saved}"
            reward_file_name = fname
    if action == 'accept':
        # Get plan default reward if no custom
        order = conn.execute('SELECT plan_id FROM orders WHERE id = ?', (order_id,)).fetchone()
        if not reward_text and order:
            plan = conn.execute('SELECT reward FROM plans WHERE id = ?', (order['plan_id'],)).fetchone()
            if plan and plan['reward']:
                reward_text = plan['reward']
        conn.execute('''UPDATE orders SET status = ?, admin_note = ?, reward_text = ?, reward_file = ?, reward_file_name = ?, updated_at = ?
                        WHERE id = ?''',
                     ('accepted', note, reward_text, reward_file, reward_file_name, datetime.now().isoformat(), order_id))
        flash('Order accepted! Reward delivered to user.', 'success')
    elif action == 'cancel':
        conn.execute('UPDATE orders SET status = ?, admin_note = ?, updated_at = ? WHERE id = ?',
                     ('cancelled', note, datetime.now().isoformat(), order_id))
        flash('Order cancelled (suspended).', 'success')
    elif action == 'suspend':
        conn.execute('UPDATE orders SET status = ?, admin_note = ?, updated_at = ? WHERE id = ?',
                     ('suspended', note, datetime.now().isoformat(), order_id))
        flash('Order suspended.', 'success')
    conn.commit()
    conn.close()
    return redirect(url_for('admin_panel') + '#orders')

@app.route('/admin/add_review', methods=['POST'])
def add_review():
    if 'admin_id' not in session:
        return redirect(url_for('login'))
    name = request.form.get('display_name', '').strip()
    content = request.form.get('content', '').strip()
    reward = request.form.get('reward_text', '').strip()
    rating = int(request.form.get('rating', 5) or 5)
    if name and content:
        conn = get_db()
        conn.execute('INSERT INTO reviews (display_name, content, reward_text, rating, created_at) VALUES (?, ?, ?, ?, ?)',
                     (name, content, reward, rating, datetime.now().isoformat()))
        conn.commit()
        conn.close()
        flash('Review added!', 'success')
    return redirect(url_for('admin_panel') + '#reviews')

@app.route('/admin/delete_review/<int:rid>', methods=['POST'])
def delete_review(rid):
    if 'admin_id' not in session:
        return redirect(url_for('login'))
    conn = get_db()
    conn.execute('DELETE FROM reviews WHERE id = ?', (rid,))
    conn.commit()
    conn.close()
    flash('Review deleted!', 'success')
    return redirect(url_for('admin_panel') + '#reviews')

@app.route('/admin/add_announcement', methods=['POST'])
def add_announcement():
    if 'admin_id' not in session:
        return redirect(url_for('login'))
    title = request.form.get('title', '').strip()
    content = request.form.get('content', '').strip()
    if title and content:
        conn = get_db()
        conn.execute('INSERT INTO announcements (title, content, created_at) VALUES (?, ?, ?)',
                     (title, content, datetime.now().isoformat()))
        conn.commit()
        conn.close()
        flash('Announcement posted!', 'success')
    return redirect(url_for('admin_panel') + '#announcements')

@app.route('/admin/delete_announcement/<int:aid>', methods=['POST'])
def delete_announcement(aid):
    if 'admin_id' not in session:
        return redirect(url_for('login'))
    conn = get_db()
    conn.execute('DELETE FROM announcements WHERE id = ?', (aid,))
    conn.commit()
    conn.close()
    flash('Announcement deleted!', 'success')
    return redirect(url_for('admin_panel') + '#announcements')

@app.route('/admin/user/<int:uid>/<action>', methods=['POST'])
def manage_user(uid, action):
    if 'admin_id' not in session:
        return redirect(url_for('login'))
    conn = get_db()
    if action == 'ban':
        conn.execute('UPDATE users SET is_banned = 1 WHERE id = ?', (uid,))
        flash('User banned.', 'success')
    elif action == 'unban':
        conn.execute('UPDATE users SET is_banned = 0 WHERE id = ?', (uid,))
        flash('User unbanned.', 'success')
    elif action == 'delete':
        conn.execute('DELETE FROM chat_messages WHERE user_id = ?', (uid,))
        conn.execute('DELETE FROM orders WHERE user_id = ?', (uid,))
        conn.execute('DELETE FROM users WHERE id = ?', (uid,))
        flash('User deleted.', 'success')
    conn.commit()
    conn.close()
    return redirect(url_for('admin_panel') + '#users')

@app.route('/admin/chat/<int:uid>', methods=['GET', 'POST'])
def admin_chat(uid):
    if 'admin_id' not in session:
        return redirect(url_for('login'))
    conn = get_db()
    user = conn.execute('SELECT * FROM users WHERE id = ?', (uid,)).fetchone()
    if not user:
        conn.close()
        flash('User not found', 'error')
        return redirect(url_for('admin_panel'))
    if request.method == 'POST':
        msg = request.form.get('message', '').strip()
        file_path = None
        file_name = None
        if 'file' in request.files:
            f = request.files['file']
            if f and f.filename and allowed_file(f.filename):
                fname = f"chat_admin_{uid}_{datetime.now().strftime('%Y%m%d%H%M%S')}_{secure_filename(f.filename)}"
                f.save(os.path.join(app.config['UPLOAD_FOLDER'], fname))
                file_path = f"uploads/{fname}"
                file_name = secure_filename(request.files['file'].filename)
        if msg or file_path:
            conn.execute('''INSERT INTO chat_messages (user_id, sender_type, message, file_path, file_name, created_at)
                            VALUES (?, 'admin', ?, ?, ?, ?)''',
                         (uid, msg, file_path, file_name, datetime.now().isoformat()))
            conn.commit()
        return redirect(url_for('admin_chat', uid=uid))
    conn.execute('UPDATE chat_messages SET is_read = 1 WHERE user_id = ? AND sender_type = ?', (uid, 'user'))
    conn.commit()
    messages = conn.execute('SELECT * FROM chat_messages WHERE user_id = ? ORDER BY id ASC', (uid,)).fetchall()
    conn.close()
    return render_template('admin_chat.html',
                           messages=messages,
                           chat_user=user,
                           site_name=site_name(),
                           admin_username=session.get('admin_username'))

if __name__ == '__main__':
    os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
    init_db()
    print("=" * 55)
    print(f"  {site_name()} — Server: http://127.0.0.1:5000")
    print("  Admin: admin / admin123")
    print("=" * 55)
    app.run(debug=True, host='0.0.0.0', port=5000)
